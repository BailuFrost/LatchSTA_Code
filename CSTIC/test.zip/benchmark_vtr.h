/**
 * @file benchamrk_vtr.h
 * @brief 找到对应的函数并执行
 * @details
 * @author zli
 * @email lizhen19@fudan.edu.cn
 * @version 1.0
 * @date 2020-12-07
*/
#ifndef GUARD_function
#define GUARD_function

#include <string>
void benchmark_vtr(const std::string&);

#endif