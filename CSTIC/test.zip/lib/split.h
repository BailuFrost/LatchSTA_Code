#ifndef GUARD_split
#define GUARD_split

#include <vector>
#include <string>



std::vector<std::string> split(const std::string&);
bool space(char);
bool not_space(char);

#endif
